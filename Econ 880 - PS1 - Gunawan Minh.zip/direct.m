function result = direct(x,y)
    result = (83521*y^8) + (578*x^2*y^4) - (2*x^4) + (2*x^6) - (x^8);
end   


